
package emart.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DBConnection {
    private static Connection conn;
    static
    {
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            conn=DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-SFTHDT0:1521/xe","emart","myself");
            JOptionPane.showMessageDialog(null,"connection opened successfully","success",JOptionPane.INFORMATION_MESSAGE);
                                
        }
        catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null,"error in loading the driver","Driver Error!",JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
            System.exit(1);
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"error in opening the connection","DB Error!",JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
            System.exit(1);
        }
    }
    public static Connection getConnection(){
    return conn;
    }
    public static void closeConnection(){
          try{
            conn.close();
             JOptionPane.showMessageDialog(null,"connection close successfully","success",JOptionPane.INFORMATION_MESSAGE);
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"error in closing the connection","DB Error!",JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
           
        }
}
}
