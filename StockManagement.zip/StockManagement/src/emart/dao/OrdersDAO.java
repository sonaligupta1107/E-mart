
package emart.dao;

import emart.dbutil.DBConnection;
import emart.pojo.ProductsPojo;
import emart.pojo.UserProfile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OrdersDAO {
     public static String getNextOrderId()throws SQLException{
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();        
        ResultSet rs=st.executeQuery("Select max(order_id) from orders");
        rs.next();
        String id=rs.getString(1);
        if(id==null)
            return "O-101";
        int oId=Integer.parseInt(id.substring(2));
        oId++;
        return "O-"+oId;
    }
     
     public static boolean addOrder(ArrayList<ProductsPojo> al , String ordId)throws SQLException{
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("insert into orders values(?,?,?,?)");
         int count=0;
         for(ProductsPojo p:al){
                ps.setString(1, ordId);
                ps.setString(2, p.getProductId());
                ps.setInt(3,p.getQuantity());
                ps.setString(4,UserProfile.getUserid());
                count+=ps.executeUpdate();
      }
          return count==al.size();
}
     public static Set<String> getallOrderIds()throws SQLException{
         Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();        
        ResultSet rs=st.executeQuery("Select order_id from orders");
         Set<String> allOrders = new HashSet<String>();
         while(rs.next()){
             allOrders.add(rs.getString(1));
         }
        return allOrders;
     }
     public static List<ProductsPojo> getDetailsByOrderId(String oId)throws SQLException{
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement(" select orders.p_id,products.p_name,products.p_companyname,products.p_price,products.our_price,products.p_tax,orders.quantity from orders,products where orders.p_id=products.p_id and orders.order_id=?");
        ps.setString(1, oId);
         ResultSet rs=ps.executeQuery();
         ArrayList <ProductsPojo> allItems=new ArrayList();
         while(rs.next()){
            ProductsPojo p=new ProductsPojo();
              p.setProductId(rs.getString("p_id"));
              p.setProductName(rs.getString("p_name"));
              p.setProductCompany(rs.getString("p_companyname"));
              p.setProductPrice(rs.getDouble("p_price"));
              p.setOurPrice(rs.getDouble("our_price"));
              p.setTax(rs.getInt("p_tax"));
              p.setQuantity(rs.getInt("quantity"));

              allItems.add(p);
             
         }
        return allItems;
     }
}










//select orders.p_id,products.p_name,products.p_companyname,products.p_price,products.our_price,products.p_tax,orders.quantity from orders,products where orders.p_id=products.p_id and orders.order_id=?











//    public static List<ProductPojo> getOrders(String orderId) throws SQLException {
//        PreparedStatement ps = DBConnection.getConnection()
//                .prepareStatement("select "
//                        + "orders.order_id,"
//                        + "orders.userid,"
//                        + "orders.p_id,"
//                        + "products.p_name,"
//                        + "products.p_company_name,"
//                        + "orders.p_price,"
//                        + "orders.our_price,"
//                        + "orders.p_tax,"
//                        + "orders.quantity "
//                        + "from orders, products "
//                        + "where "
//                        + "orders.p_id = products.p_id "
//                        + "and "
//                        + "orders.userid=? "
//                        + "and "
//                        + "orders.order_id=?");
//        ps.setString(1, UserProfile.getUserId());
//        ps.setString(2, orderId);
//        ResultSet rs = ps.executeQuery();
//        ArrayList<ProductPojo> orders = new ArrayList<>();
//        while (rs.next()) {
//
//            ProductPojo p = new ProductPojo(
//                    rs.getString("p_id"),
//                    rs.getString("p_name"),
//                    rs.getString("p_company_name"),
//                    rs.getDouble("p_price"),
//                    rs.getDouble("our_price"),
//                    rs.getInt("p_tax"),
//                    rs.getInt("quantity")
//            );
//            orders.add(p);
//        }
//        return orders;
//    }
//
//    public static List<ProductPojo> getAllOrders(String orderId) throws SQLException {
//        PreparedStatement ps = DBConnection.getConnection()
//                .prepareStatement("select orders.order_id,orders.userid,orders.p_id,products.p_name,products.p_company_name,orders.p_price,orders.our_price,orders.p_tax,
//                                                        orders.quantity from orders, products where orders.p_id = products.p_id and orders.order_id=?");
//        ps.setString(1, orderId);
//        ResultSet rs = ps.executeQuery();
//        ArrayList<ProductPojo> orders = new ArrayList<>();
//        while (rs.next()) {
//
//            ProductPojo p = new ProductPojo(
//                    rs.getString("p_id"),
//                    rs.getString("p_name"),
//                    rs.getString("p_company_name"),
//                    rs.getDouble("p_price"),
//                    rs.getDouble("our_price"),
//                    rs.getInt("p_tax"),
//                    rs.getInt("quantity")
//            );
//            orders.add(p);
//        }
//        return orders;
//    }
//package emart.dao;
//
//import emart.dbutil.DBConnection;
//import emart.pojo.ProductsPojo;
//import emart.pojo.UserProfile;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//public class OrdersDAO {
//     public static String getNextOrderId()throws SQLException{
//        Connection conn=DBConnection.getConnection();
//        Statement st=conn.createStatement();        
//        ResultSet rs=st.executeQuery("Select max(order_id) from orders");
//        rs.next();
//        String id=rs.getString(1);
//        if(id==null)
//            return "O-101";
//        int oId=Integer.parseInt(id.substring(2));
//        oId++;
//        return "O-"+oId;
//    }
//     
//     public static boolean addOrder(ArrayList<ProductsPojo> al , String ordId)throws SQLException{
//         Connection conn=DBConnection.getConnection();
//         PreparedStatement ps=conn.prepareStatement("insert into orders values(?,?,?,?)");
//         int count=0;
//         for(ProductsPojo p:al){
//                ps.setString(1, ordId);
//                ps.setString(2, p.getProductId());
//                ps.setInt(3,p.getQuantity());
//                ps.setString(4,UserProfile.getUserid());
//                count+=ps.executeUpdate();
//      }
//          return count==al.size();
//}
//     public static Set<String> getallOrderIds()throws SQLException{
//         Connection conn=DBConnection.getConnection();
//        Statement st=conn.createStatement();        
//        ResultSet rs=st.executeQuery("Select order_id from orders");
//         Set<String> allOrders = new HashSet<String>();
//         while(rs.next()){
//             allOrders.add(rs.getString(1));
//         }
//        return allOrders;
//     }
//     public static List<ProductsPojo> getDetailsByOrderId(String oId)throws SQLException{
//         Connection conn=DBConnection.getConnection();
//          Statement st=conn.createStatement();        
//          ResultSet rs=st.executeQuery("Select orders.p_id, P_NAME ,P_COMPANYNAME, P_PRICE,OUR_PRICE,orders.quantity, P_TAX from orders,products where order_id='"+oId+"'");
////        PreparedStatement ps=conn.prepareStatement ("Select * from orders where order_id=?");
////        ps.setString(1, oId);
//        
//        
//        List<ProductsPojo> allOrders=new ArrayList<>();
//        
//        
//        return allOrders;
//     }
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////    public static List<ProductPojo> getOrders(String orderId) throws SQLException {
////        PreparedStatement ps = DBConnection.getConnection()
////                .prepareStatement("select "
////                        + "orders.order_id,"
////                        + "orders.userid,"
////                        + "orders.p_id,"
////                        + "products.p_name,"
////                        + "products.p_company_name,"
////                        + "orders.p_price,"
////                        + "orders.our_price,"
////                        + "orders.p_tax,"
////                        + "orders.quantity "
////                        + "from orders, products "
////                        + "where "
////                        + "orders.p_id = products.p_id "
////                        + "and "
////                        + "orders.userid=? "
////                        + "and "
////                        + "orders.order_id=?");
////        ps.setString(1, UserProfile.getUserId());
////        ps.setString(2, orderId);
////        ResultSet rs = ps.executeQuery();
////        ArrayList<ProductPojo> orders = new ArrayList<>();
////        while (rs.next()) {
////
////            ProductPojo p = new ProductPojo(
////                    rs.getString("p_id"),
////                    rs.getString("p_name"),
////                    rs.getString("p_company_name"),
////                    rs.getDouble("p_price"),
////                    rs.getDouble("our_price"),
////                    rs.getInt("p_tax"),
////                    rs.getInt("quantity")
////            );
////            orders.add(p);
////        }
////        return orders;
////    }
////
////    public static List<ProductPojo> getAllOrders(String orderId) throws SQLException {
////        PreparedStatement ps = DBConnection.getConnection()
////                .prepareStatement("select "
////                        + "orders.order_id,"
////                        + "orders.userid,"
////                        + "orders.p_id,"
////                        + "products.p_name,"
////                        + "products.p_company_name,"
////                        + "orders.p_price,"
////                        + "orders.our_price,"
////                        + "orders.p_tax,"
////                        + "orders.quantity "
////                        + "from orders, products "
////                        + "where "
////                        + "orders.p_id = products.p_id "
////                        + "and "
////                        + "orders.order_id=?");
////        ps.setString(1, orderId);
////        ResultSet rs = ps.executeQuery();
////        ArrayList<ProductPojo> orders = new ArrayList<>();
////        while (rs.next()) {
////
////            ProductPojo p = new ProductPojo(
////                    rs.getString("p_id"),
////                    rs.getString("p_name"),
////                    rs.getString("p_company_name"),
////                    rs.getDouble("p_price"),
////                    rs.getDouble("our_price"),
////                    rs.getInt("p_tax"),
////                    rs.getInt("quantity")
////            );
////            orders.add(p);
////        }
////        return orders;
////    }