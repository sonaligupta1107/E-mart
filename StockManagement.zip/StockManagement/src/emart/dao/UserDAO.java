
package emart.dao;

import emart.dbutil.DBConnection;
import emart.pojo.EmployeePojo;
import emart.pojo.UserPojo;
import emart.pojo.UserProfile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    public static boolean validateUser(UserPojo user)throws SQLException
    {
            Connection conn=DBConnection.getConnection();
            PreparedStatement ps=conn.prepareStatement("Select * from users where userid=? and password=? and usertype=?");
            ps.setString(1,user.getUserId());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getUserType());
            
            ResultSet rs =ps.executeQuery();
            if(rs.next()){
                String username=rs.getString(5);
                UserProfile.setUsername(username);              //ye yha pe hi kyyu??
                return true;
            }
            return false;
            
    }
    public static boolean isUserPresent(String empid )throws SQLException{
         Connection conn=DBConnection.getConnection();
            PreparedStatement ps=conn.prepareStatement("Select 1 from users where empid=?");
            ps.setString(1,empid);
            ResultSet rs =ps.executeQuery();
            return rs.next();
    }
    
    public static boolean addUser(UserPojo rec)throws SQLException{
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("Insert into users values(?,?,?,?,?)");
        ps.setString(1, rec.getUserId());
        ps.setString(2, rec.getEmpId());
        ps.setString(3, rec.getPassword());
        ps.setString(4, rec.getUserType());
        ps.setString(5,rec.getUserName());
        
        int result=ps.executeUpdate();
        return result==1;        
    }
    
//    public static List<UserPojo> getAllReceptionistDetails() throws SQLException{
//        
//        Connection conn=DBConnection.getConnection();
//        Statement st=conn.createStatement();
//        
//        ResultSet rs=st.executeQuery("Select * from users  where usertype='Receptionist' order by empid");
//        List<UserPojo> allRec=new ArrayList<>();
//        while(rs.next()){
//            UserPojo emp=new UserPojo();
//            emp.setEmpId(rs.getString(2));
//            emp.setUserId(rs.getString(1));
//            emp.setPassword(rs.getString(3));
//            emp.setUserName(rs.getString(5));
//            
//            allRec.add(emp);
//        }      
//        return allRec;
//    }

    
//     public static UserPojo getRecDetailsbyId(String userid)throws SQLException{
//      Connection conn=DBConnection.getConnection();
//      PreparedStatement ps=conn.prepareStatement("select * from users where userid=?");
//      ps.setString(1, userid);
//      ResultSet rs=ps.executeQuery();
//      
//           rs.next();
//           UserPojo rec=new UserPojo();
//          rec.setUserId(rs.getString(1));
//          rec.setUserName(rs.getString(5));
//      
//      return rec;      
//  } 
  
}
