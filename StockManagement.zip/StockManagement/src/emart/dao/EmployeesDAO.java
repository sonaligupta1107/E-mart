/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emart.dao;

import emart.dbutil.DBConnection;
import emart.pojo.EmployeePojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hp
 */
public class EmployeesDAO {
    public static String getNextEmpId()throws SQLException{
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        
        ResultSet rs=st.executeQuery("Select max(empid) from employees");
        rs.next();
        String id =rs.getString(1).substring(3);
        int empId=Integer.parseInt(id)+1;
        return "EMP"+empId;
    }
    
    public static boolean addEmployees(EmployeePojo emp)throws SQLException{
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("Insert into Employees values (?,?,?,?)");
        ps.setString(1, emp.getEmpId());
        ps.setString(2,emp.getEmpName());
        ps.setString(3, emp.getJob());
        ps.setDouble(4,emp.getSalary());
        
        int result =ps.executeUpdate();
        return result==1;
    }
    
    public static List<EmployeePojo> getAllEmployeeDetails() throws SQLException{
        
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        
        ResultSet rs=st.executeQuery("Select * from employees order by empid");
        List<EmployeePojo> allEmp=new ArrayList<>();
        while(rs.next()){
            EmployeePojo emp=new EmployeePojo();
            emp.setEmpId(rs.getString(1));
            emp.setEmpName(rs.getString(2));
            emp.setJob(rs.getString(3));
            emp.setSalary(rs.getDouble(4));
            
            allEmp.add(emp);
        }      
        return allEmp;
    }
    
    public static List getAllEmployeeIds()throws SQLException{
         Connection conn=DBConnection.getConnection();
         Statement st=conn.createStatement();
         ResultSet rs=st.executeQuery("select Empid from employees order by empid");
         List<String> allEmp=new ArrayList<>();
         while(rs.next()){
             allEmp.add(rs.getString(1));
         }
         return allEmp;
}
  public static EmployeePojo getEmpDetailsbyId(String empid)throws SQLException{
      Connection conn=DBConnection.getConnection();
      PreparedStatement ps=conn.prepareStatement("select * from employees where empid=?");
      ps.setString(1, empid);
      ResultSet rs=ps.executeQuery();
      
           rs.next();
           EmployeePojo emp=new EmployeePojo();
          emp.setEmpId(rs.getString(1));
          emp.setEmpName(rs.getString(2));
          emp.setJob(rs.getString(3));
          emp.setSalary(rs.getDouble(4));
      
      return emp;      
  }  
  public static boolean updateEmployee(EmployeePojo emp)throws SQLException{
      Connection conn=DBConnection.getConnection();
      PreparedStatement ps=conn.prepareStatement("update employees set EmpName=?,job=?,salary=? where empid=?");
      ps.setString(1, emp.getEmpName());
      ps.setString(2, emp.getJob());
      ps.setDouble(3, emp.getSalary());
      ps.setString(4,emp.getEmpId());      
      int result =ps.executeUpdate();
      
      if(result==0)
           return false;
      else{
          boolean r =UserDAO.isUserPresent(emp.getEmpId());
            if(r==false)
                return true;
      }
      ps=conn.prepareStatement("update users set username=?,usertype=? where empid=?");
      ps.setString(1, emp.getEmpName());
      ps.setString(2, emp.getJob());      
      ps.setString(3,emp.getEmpId());
      
      int y=ps.executeUpdate();
      return y==1;
  }
  
  public static boolean removeEmployee(String empid)throws SQLException{
      Connection conn=DBConnection.getConnection();
      PreparedStatement ps=conn.prepareStatement("delete from employees where empid=?");
      ps.setString(1, empid);
      int x=ps.executeUpdate();
      return x==1;
  }
//  
//  public static List<String> findReceptionists()throws SQLException{
//       Connection conn=DBConnection.getConnection();
//       Statement st=conn.createStatement();
//       ResultSet rs=st.executeQuery("select empid from employees where job='Receptionist'order by empid");
//      
//       List<String> empId =new ArrayList<>();
//       
//       while(rs.next()){
//           empId.add(rs.getString(1));
//       }
//       return empId;
//  }
}